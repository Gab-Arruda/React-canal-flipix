# React Series
Este pacote contém os arquivos básicos para iniciar as vídeo aulas
de React do [Canal V++](https://youtube.com/user/VPlusPlus).
